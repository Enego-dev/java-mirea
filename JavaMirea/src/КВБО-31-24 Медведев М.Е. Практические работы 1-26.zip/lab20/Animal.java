package lab20;

import java.io.Serializable;

public class Animal implements Serializable {
}
