package lab1;

public class Task3 {
    public static void main(String[] args){
        // добавляем аргументы: Edit Configurations -> Arguments
        for (String arg : args){
            System.out.println(arg);
        }
    }
}
