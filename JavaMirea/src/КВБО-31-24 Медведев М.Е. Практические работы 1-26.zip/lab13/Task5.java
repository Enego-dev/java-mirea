package lab13;

public class Task5 {
    static void main() {
        IO.println(Phone.formatPhone("+89999999999"));
        IO.println(Phone.formatPhone("89999999999"));
    }
}
