package lab6.task3;

public class Phone implements Nameable{
    @Override
    public String getName() {
        return "POCO X7 PRO";
    }
}
