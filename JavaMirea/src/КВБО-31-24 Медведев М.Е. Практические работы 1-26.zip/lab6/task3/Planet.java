package lab6.task3;

public class Planet implements Nameable{
    @Override
    public String getName() {
        return "Planet: Earth";
    }
}
