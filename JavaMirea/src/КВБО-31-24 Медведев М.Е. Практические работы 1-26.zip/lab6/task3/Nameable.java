package lab6.task3;

public interface Nameable {
    String getName();
}
