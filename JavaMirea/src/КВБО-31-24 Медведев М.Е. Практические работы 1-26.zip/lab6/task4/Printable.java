package lab6.task4;

public interface Printable {
    void print();
}
