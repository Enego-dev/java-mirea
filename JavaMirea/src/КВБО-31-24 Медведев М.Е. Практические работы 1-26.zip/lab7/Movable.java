package lab7;

public interface Movable {
    void moveUp(double step);
    void moveDown(double step);
    void moveRight(double step);
    void moveLeft(double step);
}
