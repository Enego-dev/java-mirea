package lab13;

public class Task3 {
    static void main() {
        var a1 = new Address("Расия, Масковская, Киiв, Трампова, 67, 6, 7");
        var a2 = new Address("Биларусь, Картофельная; Бульба. Пюрешкина; 42, 5, 2");

        IO.println(a1);
        IO.println(a2);
    }
}
