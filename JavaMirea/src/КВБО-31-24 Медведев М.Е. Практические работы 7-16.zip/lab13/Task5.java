package lab13;

public class Task5 {
    static void main() {
        IO.println(Phone.formatPhone("+89060370601"));
        IO.println(Phone.formatPhone("89060370601"));
    }
}
