package lab7;

public interface MathCalculable {
    double pow(int a, int b);
    double absComplex(int x, int y);
    static double MathPI(){
        return 3.14;
    }
}
