package lab20;

public class Dog extends Animal {
}
