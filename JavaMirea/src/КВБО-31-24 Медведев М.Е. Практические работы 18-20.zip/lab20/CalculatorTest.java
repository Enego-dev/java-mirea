package lab20;

public class CalculatorTest {
    static void main() {
        IO.println(Calculator.sum(30f, 2.5));
        IO.println(Calculator.multiply(30f, 2.5));
        IO.println(Calculator.divide(30f, 2.5));
        IO.println(Calculator.subtraction(30f, 2.5));
    }
}
