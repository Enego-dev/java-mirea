package lab17.students;

public class StudentView {
    public void printStudentDetails(String studentRollNo, String studentName){
        IO.println("Student Roll No: " + studentRollNo);
        IO.println("Student Name: " + studentName);
    }
}
