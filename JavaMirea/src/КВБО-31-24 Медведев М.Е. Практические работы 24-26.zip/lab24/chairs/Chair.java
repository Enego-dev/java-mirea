package lab24.chairs;

public interface Chair {
    void sit();
}
