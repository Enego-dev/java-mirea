package lab6.task3;

public class Car implements Nameable{
    @Override
    public String getName() {
        return "Volvo XC90";
    }
}
