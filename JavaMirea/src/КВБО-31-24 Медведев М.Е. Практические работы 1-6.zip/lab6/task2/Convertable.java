package lab6.task2;

public interface Convertable {
    double convert(double celsiusDegrees);
}
