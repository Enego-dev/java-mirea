package lab6.task1;

public interface Priceable {
    float getPrice();
}
