package lab4_1;

public class Shape {
    public String getType(){
        return "Shape";
    }

    public double getArea(){
        return -1;
    }

    public double getPerimeter(){
        return -1;
    }
}
